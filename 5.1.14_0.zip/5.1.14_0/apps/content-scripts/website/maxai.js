(function(){window.__MAXAI__EXTENSION__VERSION__="5.1.14"})();

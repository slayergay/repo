(function() {
    const importPath = /*@__PURE__*/ JSON.parse('"apps/content-scripts/iframeDocumentEnd.js"');
    import(chrome.runtime.getURL(importPath));
})();
(function() {
    const importPath = /*@__PURE__*/ JSON.parse('"apps/content-scripts/checkMaxAIStatus.js"');
    import(chrome.runtime.getURL(importPath));
})();
import{h as c}from"./IUAZS3IM.js";import{b as l}from"./VIDU67DH.js";import{d as n}from"./27O46L5C.js";import{a as h}from"./PSEJ6ZK5.js";import{c as m,e as d}from"./LT3WP4ZW.js";import{c as p}from"./YLZJDFXB.js";import{e as f}from"./DT2UCTQJ.js";var C=`You are a knowledgeable and helpful person that can answer any questions. Your task is to answer the following question delimited by triple backticks.

Question:
\`\`\`
{query}
\`\`\`
It's possible that the question, or just a portion of it, requires relevant information from the internet to give a satisfactory answer. The relevant search results provided below, delimited by triple quotes, are the necessary information already obtained from the internet. The search results set the context for addressing the question, so you don't need to access the internet to answer the question.

Write a comprehensive answer to the question in the best way you can. If necessary, use the provided search results.

For your reference, today's date is {current_date}.

---

If you use any of the search results in your answer, always cite the sources at the end of the corresponding line, similar to how Wikipedia.org cites information. Use the citation format [[NUMBER](URL)], where both the NUMBER and URL correspond to the provided search results below, delimited by triple quotes.

Present the answer in a clear format.
Use a numbered list if it clarifies things
Make the answer as short as possible, ideally no more than 150 words.

---

If you can't find enough information in the search results and you're not sure about the answer, try your best to give a helpful response by using all the information you have from the search results.

Search results:
"""
{web_results}
"""`;var x="maxai",H="MAXAI_SEARCH_WITH_AI_ROOT_ID",I="MAXAI_SEARCH_WITH_AI_SHADOW_CONTAINER_ID",R=[],E="SEARCH_WITH_AI_LOGO_ID",S=6,v=[{name:"feature__search_with_ai__trigger_mode__always__name",value:"always",desc:"feature__search_with_ai__trigger_mode__always__desc"},{name:"feature__search_with_ai__trigger_mode__question-mask__name",value:"question-mask",desc:"feature__search_with_ai__trigger_mode__question-mask__desc"},{name:"feature__search_with_ai__trigger_mode__manual__name",value:"manual",desc:"feature__search_with_ai__trigger_mode__manual__desc"}];var U=e=>n("*[data-button-clicked-name]",e,10)||n(`.${c.root}`,e,10)||n(`.${l.root}`,e,10),y=e=>{let t="body";return n('*[id="sidebar-nav"]',e,10)?(t="side_navigation",t):n('*[id="sidebar-header"]',e,10)?(t="header",t):(t="body",t)},b=(e,t,o)=>{if(t==="minimum")return"quick_access";if(t==="floatingMenu")return"context_menu";let a=d();if(a&&a.contains(e))return"context_menu";let r=e.getAttribute("id");if(r&&r.startsWith("maxAIInputAssistant")){let i=e.getAttribute("data-button-key");if(i==="inputAssistantComposeReplyButton")return"page_instant_reply";if(i==="inputAssistantRefineDraftButton")return"page_instant_refine";if(i==="inputAssistantComposeNewButton")return"page_instant_new"}if(r&&r==="page-summary-button")return"page_summarize";if(r&&r==="pdf-summary-button")return"pdf_summarize";if(n(`div[id="${I}"]`,e,10))return"page_search_with_ai";let A=f()?"immersive":"sidebar",s=o?o.toLowerCase():"chat";if(!o){let _=m()?.querySelector("#maxAISidebarChatBox");if(_){let u=_.getAttribute("data-conversation-type")?.toLowerCase();u&&(s=u)}}return`${A}_${s}`},G=p(async(e,t,o)=>{let a=o?.buttonPosition??y(t),r=b(t,o?.sceneType,o?.conversationType);h("button_clicked",{productType:"extension",buttonName:e,buttonPosition:a,featureName:r})},300);export{C as a,x as b,H as c,I as d,R as e,E as f,S as g,v as h,U as i,G as j};

import{la as e}from"./G6E6RTNU.js";function m(r){return e}export{m as a};

var m=(r,o)=>typeof r=="string"?o(r):r(o);export{m as a};

import{a}from"./XHCCXCYD.js";import"./GAV6HCJA.js";export default a();

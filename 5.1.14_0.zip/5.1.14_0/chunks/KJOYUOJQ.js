import{l as i}from"./GUN4HCYF.js";import{f as t}from"./GAV6HCJA.js";var e=t(i()),m=e.default;export{m as a};

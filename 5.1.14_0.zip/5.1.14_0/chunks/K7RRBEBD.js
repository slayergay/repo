var T=(e,t,i)=>new Promise((m,s)=>{let r=setTimeout(()=>{m(i)},t);e.then(o=>{clearTimeout(r),m(o)}).catch(o=>{clearTimeout(r),s(o)})}),n=e=>new Promise(t=>setTimeout(t,e));export{T as a,n as b};

import{a}from"./UAB7UEHC.js";import"./GAV6HCJA.js";export{a as default};

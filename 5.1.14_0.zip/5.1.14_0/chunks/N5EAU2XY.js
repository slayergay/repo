import{a as e}from"./PJ57C2TE.js";import{f as s}from"./GAV6HCJA.js";var t=s(e()),n=r=>t.default.runtime.getURL(`/assets/USE_CHAT_GPT_AI${r}`);export{n as a};

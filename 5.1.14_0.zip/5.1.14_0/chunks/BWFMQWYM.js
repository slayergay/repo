import{r}from"./44AFAKRL.js";function a(t,u){return r(t,u)}var o=a;export{o as a};

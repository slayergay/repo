import{a}from"./TIMUG6T2.js";import"./GAV6HCJA.js";export default a();

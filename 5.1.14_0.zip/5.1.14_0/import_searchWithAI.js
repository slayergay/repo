(function() {
    const importPath = /*@__PURE__*/ JSON.parse('"searchWithAI.js"');
    import(chrome.runtime.getURL(importPath));
})();